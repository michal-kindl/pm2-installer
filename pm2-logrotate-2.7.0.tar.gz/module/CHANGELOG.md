
# 2.7.0

- [#129] fix overwrite logs in cluster mode (@EllieSummer)
- [#90] Fixed typo by changing GMT-1 to GMT+1 to match the tz (@nitrocode)
